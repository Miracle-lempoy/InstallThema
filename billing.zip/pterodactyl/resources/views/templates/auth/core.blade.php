@include('templates.Carbon.inc.LoginAnimation')

<!-- HEADER -->
<header>
    <!-- MENU -->
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="/themes/carbon/css/login/interchanging.css"/>
    <meta property="og:title" content="@if(isset($settings['meta_title'])){{ $settings['meta_title'] }}@else {{ config('app.name') }} @endif">
    <meta property="og:type" content="website">
    <meta property="og:url" content="/">
    <meta property="og:image" content="@if(isset($settings['meta_image'])){{ $settings['meta_image'] }}@else https://cdn.resourcemc.net/zAsa7/rIBOyeRU58.png/raw @endif">
    <meta property="og:description" content="@if(isset($settings['meta_desc'])){{ $settings['meta_desc'] }}@else Manage your server with an easy-to-use Panel @endif">
    <meta name="theme-color" content="@if(isset($settings['meta_color'])){{ $settings['meta_color'] }}@else #0e4688 @endif">

    <div id="{{ config('billing.author', 'n/a') }} {{ config('billing.name', 'unset') }} {{ config('billing.version', 'unset') }}" class="menu">
        <div class="logo" style="display: flex; align-items: center;">
            <img class="logo-padding" onclick="window.location.href='/'" src="@if(isset($settings['logo'])){{ $settings['logo'] }}@else /assets/svgs/pterodactyl.svg @endif" style="width: 64px; padding: 5px; cursor: pointer;">         
            <div class="logo"><a href="/">{{ config('app.name', 'Pterodactyl') }}</a></div>
        </div>
        <div class="btn" onclick="window.location.href='/portal'">
            <a target="_blank" style="color:white;">{!! Bill::lang()->get('portal') !!}</a>
        </div>
    </div>
</header>
<!-- MAIN CONTENT -->

@extends('templates/wrapper', [
    'css' => ['body' => 'bg-neutral-900']
])

@section('container')
    <div id="app"></div>
@endsection

<script>
/*===== Dynamically set icon =====*/
document.head = document.head || document.getElementsByTagName('head')[0];

function changeFavicon(src) {
    var link = document.createElement('link'),
    oldLink = document.getElementById('dynamic-favicon');
    link.id = 'dynamic-favicon';
    link.rel = 'shortcut icon';
    link.href = src;
    if (oldLink) {
        document.head.removeChild(oldLink);
    }
    document.head.appendChild(link);
}

changeFavicon('@if(isset($settings['favicon'])){{ $settings['favicon'] }}@else /favicons/favicon-32x32.png @endif');
/*===== Dynamically set icon End =====*/
</script>

<style>
/* ===== LATAR BELAKANG LOGIN ===== */
body {
    background: url('/public/themes/carbon/portal/img/wallpaper.jpg') no-repeat center center fixed;
    background-size: cover;
}

/* ===== HAPUS TOMBOL DISCORD & GITHUB ===== */
.discord, .github {
    display: none !important;
}

/* ===== VARIABEL WARNA & FONT ===== */
:root {
    --header-height: 3rem;
    --nav-width: 75px;
    --first-color: @if(isset($settings['primary_color'])){{ $settings['primary_color'] }}@else #4723d9 @endif;
    --first-color-light: #ffffff;
    --main-background: #11111d;
    --second-background: #222235;
    --text-color: #ffffff;
    --active-text-color:  #ffffff;
    --white-hover: #f4f5f7;
    --sidebar-bg-color: #161624;
    --sidebar-icon-color: #ffffff;
    --white-color: #ffffff;
    --body-font: 'Nunito', sans-serif;
    --normal-font-size: 1rem;
    --z-fixed: 100;
}

/* ===== CSS RESET ===== */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: "Lato", sans-serif;
}
a {
    text-decoration: none;
    color: var(--text-color);
}

/* ===== HEADER ===== */
header {
    position: relative;
}
header .menu {
    width: 70%;
    margin: 0 auto;
    height: 90px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    min-height: 70px;
}
header .logo a {
    color: var(--text-color);
    font-size: 2rem;
    font-weight: 700;
}

/* ===== TOMBOL LOGIN ===== */
.btn {
    padding: 15px 30px;
    background-color: var(--first-color);
    border-radius: 4px;
    color: #fff;
    font-weight: 700;
    text-transform: uppercase;
    font-size: 0.7rem;
    letter-spacing: 1px;
    cursor: pointer;
    box-shadow: var(--first-color) 0px 0 22px;
    transition: all 0.4s;
}
.btn:hover {
    box-shadow: 0px 11px 26px 0px rgba(19, 36, 51, 0);
}

/* ===== RESPONSIVE DESIGN ===== */
@media only screen and (max-width: 1250px) {
    header .menu {
        width: 90%;
    }
}
@media only screen and (max-width: 980px) {
    header .btn {
        display: none;
    }
    header .menu {
        height: 110px;
        flex-direction: column;
        justify-content: space-evenly;
    }
}
</style>